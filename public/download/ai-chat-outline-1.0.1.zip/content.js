const SITE_CONFIGS = [
  {
    name: "gemini",
    test: () => location.hostname.includes("gemini.google.com"),
    selector: ".user-query-container",
  },
  {
    name: "chatgpt",
    test: () =>
      location.hostname.includes("chat.openai.com") ||
      location.hostname.includes("chatgpt.com"),
    selector: 'div[data-message-author-role="user"]',
  },
  {
    name: "doubao",
    test: () => location.hostname.endsWith("doubao.com"),
    selector: 'div[data-testid="message_text_content"]',
  },
  {
    name: "qianwen",
    test: () =>
      location.hostname.includes("qianwen.com") ||
      (location.hostname.includes("aliyun.com") &&
        (location.hostname.includes("qianwen") || location.hostname.includes("tongyi"))) ||
      location.hostname.includes("qianwen.alibaba.com"),
    selector: 'div[class^="questionItem-"]',
  },
  {
    name: "kimi",
    test: () =>
      location.hostname.includes("kimi.moonshot.cn") ||
      location.hostname.includes("kimi.ai") ||
      location.hostname.includes("kimi.com"),
    selector: ".chat-content-item-user",
  },
  {
    name: "yiyan",
    test: () => location.hostname.includes("yiyan.baidu.com"),
    selector: 'div[class^="questionText__"]',
  },
  {
    name: "grok",
    test: () => location.hostname.includes("grok.com"),
    selector: 'div[class*="message"], div[class*="Message"]',
  },
];
const I18N = {
  en: { title: "My Question Outline", empty: "(Empty)", collapse: "Collapse", expand: "Expand" },
  zh: { title: "我的问题目录", empty: "(空内容)", collapse: "折叠", expand: "展开" },
  ja: { title: "自分の質問の目次", empty: "(空の内容)", collapse: "折りたたむ", expand: "展開" },
  de: { title: "Mein Fragenverzeichnis", empty: "(Leer)", collapse: "Einklappen", expand: "Ausklappen" },
  it: { title: "Indice delle mie domande", empty: "(Vuoto)", collapse: "Comprimi", expand: "Espandi" },
};
function langCode() {
  const l = (navigator.language || "en").toLowerCase();
  if (l.startsWith("zh")) return "zh";
  if (l.startsWith("ja")) return "ja";
  if (l.startsWith("de")) return "de";
  if (l.startsWith("it")) return "it";
  return "en";
}
function tr(k) {
  const d = I18N[langCode()] || I18N.en;
  return d[k] || I18N.en[k] || k;
}
function currentConfig() {
  return SITE_CONFIGS.find((c) => {
    try {
      return c.test();
    } catch {
      return false;
    }
  });
}
function currentSelector() {
  const cfg = currentConfig();
  return cfg ? cfg.selector : null;
}
const hostOk = !!currentConfig();
const LOG_PREFIX = "[QueryTOC]";
function dlog() {
  try {
    const args = Array.from(arguments);
    console.log(LOG_PREFIX, ...args);
  } catch {}
}
let panel;
let listEl;
let toggleBtn;
let observer;
let updateTimer;
function init() {
  if (!hostOk) return;
  if (document.getElementById("gemini-query-toc")) return;
  createPanel();
  buildItems();
  observeChanges();
}
function createPanel() {
  panel = document.createElement("div");
  panel.id = "gemini-query-toc";
  panel.className = "gemini-query-toc";
  const header = document.createElement("div");
  header.className = "toc-header";
  const title = document.createElement("div");
  title.className = "toc-title";
  title.textContent = tr("title");
  const controls = document.createElement("div");
  controls.className = "toc-controls";
  toggleBtn = document.createElement("button");
  toggleBtn.className = "toc-toggle";
  toggleBtn.type = "button";
  toggleBtn.textContent = tr("collapse");
  toggleBtn.addEventListener("click", () => {
    panel.classList.toggle("collapsed");
    toggleBtn.textContent = panel.classList.contains("collapsed") ? tr("expand") : tr("collapse");
  });
  const moreBtn = document.createElement("button");
  moreBtn.className = "toc-more";
  moreBtn.type = "button";
  moreBtn.textContent = "⋯";
  moreBtn.title = "更多";
  moreBtn.setAttribute("aria-label", "更多");
  moreBtn.addEventListener("click", () => {
    try {
      window.open("https://aihelper360.com/", "_blank", "noopener");
    } catch {
      location.href = "https://aihelper360.com/";
    }
  });
  enableDrag(header);
  header.appendChild(title);
  controls.appendChild(toggleBtn);
  controls.appendChild(moreBtn);
  header.appendChild(controls);
  listEl = document.createElement("div");
  listEl.className = "toc-list";
  panel.appendChild(header);
  panel.appendChild(listEl);
  document.documentElement.appendChild(panel);
}
function enableDrag(handle) {
  let dragging = false;
  let startX = 0;
  let startY = 0;
  let originLeft = 0;
  let originTop = 0;
  function onPointerDown(e) {
    if (e.button !== 0) return;
    if (e.target && (e.target.closest(".toc-toggle") || e.target.closest(".toc-more"))) return;
    dragging = true;
    startX = e.clientX;
    startY = e.clientY;
    const rect = panel.getBoundingClientRect();
    originLeft = rect.left;
    originTop = rect.top;
    panel.style.left = originLeft + "px";
    panel.style.top = originTop + "px";
    panel.style.right = "auto";
    document.addEventListener("pointermove", onPointerMove);
    document.addEventListener("pointerup", onPointerUp, { once: true });
  }
  function onPointerMove(e) {
    if (!dragging) return;
    const dx = e.clientX - startX;
    const dy = e.clientY - startY;
    let nextLeft = originLeft + dx;
    let nextTop = originTop + dy;
    const pad = 8;
    const maxLeft = Math.max(pad, window.innerWidth - panel.offsetWidth - pad);
    const maxTop = Math.max(pad, window.innerHeight - panel.offsetHeight - pad);
    nextLeft = Math.min(maxLeft, Math.max(pad, nextLeft));
    nextTop = Math.min(maxTop, Math.max(pad, nextTop));
    panel.style.left = Math.round(nextLeft) + "px";
    panel.style.top = Math.round(nextTop) + "px";
  }
  function onPointerUp() {
    dragging = false;
    document.removeEventListener("pointermove", onPointerMove);
  }
  handle.addEventListener("pointerdown", onPointerDown);
}
function getQueries() {
  const sel = currentSelector();
  if (!sel) return [];
  const all = Array.from(document.querySelectorAll(sel));
  const visible = all.filter(isVisible);
  const userOnly = visible.filter(isUserMessage);
  if (currentSiteName() === "doubao") {
    const sample = visible.slice(0, 5).map((el) => {
      const rect = el.getBoundingClientRect();
      const ancUser = !!el.closest(
        '[data-message-author-role="user"], [data-role="user"], .message-item.user, .chat-message.user, [class*="user"][class*="message"], [data-testid="message_item_user"]'
      );
      const ancAssistant = !!el.closest(
        '[data-message-author-role="assistant"], [data-role="assistant"], .message-item.assistant, .chat-message.assistant, [data-testid="message_item_assistant"]'
      );
      return { left: Math.round(rect.left), rightAligned: rect.left > window.innerWidth * 0.55, ancUser, ancAssistant, text: textOf(el) };
    });
    dlog("getQueries", { site: currentSiteName(), selector: sel, all: all.length, visible: visible.length, user: userOnly.length, sample });
  } else if (currentSiteName() === "qianwen") {
    const sample = visible.slice(0, 5).map((el) => {
      const rect = el.getBoundingClientRect();
      const classes = el.className || "";
      const isQuestion = /^questionItem-/.test(classes);
      return { left: Math.round(rect.left), width: Math.round(rect.width), classes, isQuestion, text: textOf(el) };
    });
    dlog("getQueries", { site: currentSiteName(), selector: sel, all: all.length, visible: visible.length, user: userOnly.length, sample });
  } else if (currentSiteName() === "kimi") {
    // no logging for Kimi when stable
  } else if (currentSiteName() === "yiyan") {
    const sample = visible.slice(0, 5).map((el) => {
      const rect = el.getBoundingClientRect();
      const classes = el.className || "";
      const isQuestion = /^questionText__/.test(classes);
      return { left: Math.round(rect.left), width: Math.round(rect.width), classes, isQuestion, text: textOf(el) };
    });
    dlog("getQueries", { site: currentSiteName(), selector: sel, all: all.length, visible: visible.length, user: userOnly.length, sample });
  } else {
    dlog("getQueries", { site: currentSiteName(), selector: sel, all: all.length, visible: visible.length, user: userOnly.length });
  }
  return userOnly;
}
function isVisible(el) {
  if (!el.isConnected) return false;
  if (el.closest('[aria-hidden="true"]')) return false;
  const style = getComputedStyle(el);
  if (style.display === "none" || style.visibility === "hidden" || style.opacity === "0") return false;
  const rect = el.getBoundingClientRect();
  if (rect.width === 0 || rect.height === 0) return false;
  return true;
}
function currentSiteName() {
  const cfg = currentConfig();
  return cfg ? cfg.name : null;
}
function isUserMessage(el) {
  const site = currentSiteName();
  if (site === "doubao") {
    const ancUser = el.closest(
      '[data-message-author-role="user"], [data-role="user"], .message-item.user, .chat-message.user, [class*="user"][class*="message"], [data-testid="message_item_user"]'
    );
    const ancAssistant = el.closest(
      '[data-message-author-role="assistant"], [data-role="assistant"], .message-item.assistant, .chat-message.assistant, [data-testid="message_item_assistant"]'
    );
    if (ancUser) return true;
    if (ancAssistant) return false;
    const rect = el.getBoundingClientRect();
    const rightAligned = rect.left > window.innerWidth * 0.55;
    return rightAligned;
  } else if (site === "kimi") {
    return !!el.closest(".chat-content-item-user");
  } else if (site === "grok") {
    const ancUser = el.closest(
      '[data-message-author-role="user"], [data-role="user"], .message-item.user, .chat-message.user, [class*="user"][class*="message"], [data-testid="message_item_user"]'
    );
    const ancAssistant = el.closest(
      '[data-message-author-role="assistant"], [data-role="assistant"], .message-item.assistant, .chat-message.assistant, [data-testid="message_item_assistant"]'
    );
    if (ancUser) return true;
    if (ancAssistant) return false;
    const rect = el.getBoundingClientRect();
    const rightAligned = rect.left > window.innerWidth * 0.55;
    return rightAligned;
  }
  return true;
}
function textOf(el) {
  const t = (el.textContent || "").replace(/\s+/g, " ").trim();
  if (!t) return tr("empty");
  if (t.length <= 40) return t;
  return t.slice(0, 40) + "…";
}
function fullText(el) {
  return (el.textContent || "").replace(/\s+/g, " ").trim();
}
function buildItems() {
  const queries = getQueries();
  const seen = new Set();
  const unique = [];
  for (const q of queries) {
    const key = fullText(q);
    if (!key) continue;
    if (seen.has(key)) continue;
    seen.add(key);
    unique.push(q);
  }
  dlog("buildItems unique", unique.length, unique.slice(0, 5).map((q) => textOf(q)));
  const frag = document.createDocumentFragment();
  listEl.innerHTML = "";
  unique.forEach((q, i) => {
    q.dataset.tocIndex = String(i + 1);
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "toc-item";
    const idx = document.createElement("span");
    idx.className = "toc-index";
    idx.textContent = String(i + 1);
    const txt = document.createElement("span");
    txt.className = "toc-text";
    txt.textContent = textOf(q);
    btn.appendChild(idx);
    btn.appendChild(txt);
    btn.addEventListener("click", () => scrollToQuery(q));
    frag.appendChild(btn);
  });
  listEl.appendChild(frag);
  panel.style.display = unique.length ? "block" : "none";
}
function scrollToQuery(el) {
  try {
    el.scrollIntoView({ behavior: "smooth", block: "start" });
    el.classList.add("toc-highlight");
    setTimeout(() => el.classList.remove("toc-highlight"), 1500);
  } catch {}
}
function observeChanges() {
  if (observer) observer.disconnect();
  observer = new MutationObserver((mutations) => {
    let changed = false;
    const sel = currentSelector();
    if (!sel) {
      dlog("observer no selector", currentSiteName());
      return;
    }
    for (const m of mutations) {
      if (m.type === "childList") {
        if (m.addedNodes && m.addedNodes.length) {
          for (const n of m.addedNodes) {
            if (!(n instanceof Element)) continue;
            if (n.matches && n.matches(sel)) {
              changed = true;
              break;
            }
            if (n.querySelector && n.querySelector(sel)) {
              changed = true;
              break;
            }
          }
        }
        if (m.removedNodes && m.removedNodes.length) {
          for (const n of m.removedNodes) {
            if (!(n instanceof Element)) continue;
            if (n.matches && n.matches(sel)) {
              changed = true;
              break;
            }
            if (n.querySelector && n.querySelector(sel)) {
              changed = true;
              break;
            }
          }
        }
      }
    }
    if (changed) {
      dlog("observer change detected, schedule update");
      scheduleUpdate();
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });
}
function scheduleUpdate() {
  clearTimeout(updateTimer);
  updateTimer = setTimeout(buildItems, 300);
}
function waitForFirstQuery() {
  dlog("waitForFirstQuery initial", { site: currentSiteName(), selector: currentSelector(), count: getQueries().length });
  if (getQueries().length) {
    init();
    return;
  }
  const t = setInterval(() => {
    if (getQueries().length) {
      clearInterval(t);
      dlog("first queries detected, init");
      init();
    }
  }, 800);
}
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", waitForFirstQuery);
} else {
  waitForFirstQuery();
}
